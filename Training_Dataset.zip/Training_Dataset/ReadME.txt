The dataset consists of 3 folders:

1: the dieletric materials with homogeneous participating medium. 

Naming convention is as follows: extinctionCoefficient_albedo_alpha.jpg
i.e. the material depicted in 4_0.9_0.05.jpg has 
extinction coefficient (sigmaT) equal to 4;
albedo equal to 0.9;
and alpha (surface roughness) equal to 0.05.



2. Opaque materials rendered with Ward's heuristic model. 

Naming convention is as follows: S_ASD_Alpha_Specular_Diffuse.jpg
S - stands for a Sphere
ASD - stand for Alpha, Specular, and Diffuse. 
The material depicted in S_ASD_0.04_0.033_0.03.jpg has
alpha equaul to 0.04;
Ward's specular reflection component equal to 0.033;
Ward's diffuse reflection component equal to 0.03.


3. the dieletric materials with homogeneous participating medium. 

Naming convention is as follows: sphere_alpha_X_sigT_X_albedo_X_sampl_X.jpg
Each X number corresponds to a parameter immediately preceeding it. 
For example, the material depicted in sphere_alpha_0.15_sigT_1.5_albedo_1_sampl_16384.jpg has
alpha equal to 0.15;
sigT (extinction coefficient) equal to 1.5;
albedo equal to 1;
and samples per pixel equal to 16384. 